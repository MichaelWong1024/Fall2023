import numpy as np
import heapq
import math
import sys

def read_tsp_file(file_path):
    """
    Reads a TSP file and extracts the coordinates of the points.
    
    Args:
    file_path (str): Path to the TSP file.
    
    Returns:
    list of tuples: A list where each tuple represents the coordinates (x, y) of a point.
    """
    with open(file_path, 'r') as file:
        lines = file.readlines()
        start_index = lines.index("NODE_COORD_SECTION\n") + 1
        end_index = lines.index("EOF\n")
        points = []
        for line in lines[start_index:end_index]:
            _, x, y = line.strip().split()
            points.append((float(x), float(y)))
    return points

def calculate_distance(point1, point2):
    """
    Calculate the Euclidean distance between two points.

    Args:
    point1, point2 (tuple): Points in the format (x, y).

    Returns:
    float: Euclidean distance between point1 and point2.
    """
    return math.sqrt((point1[0] - point2[0])**2 + (point1[1] - point2[1])**2)

def prim_mst(points):
    """
    Constructs a Minimum Spanning Tree (MST) using Prim's algorithm.

    Args:
    points (list of tuples): List of points where each tuple represents (x, y) coordinates.

    Returns:
    list of tuples: List of edges in the MST, where each edge is represented as a tuple (start_point, end_point).
    """
    num_points = len(points)
    if num_points == 0:
        return []

    mst_edges = []
    visited = [False] * num_points
    min_heap = [(0, 0)]  # Starting from point 0

    while min_heap:
        cost, current_point = heapq.heappop(min_heap)
        if visited[current_point]:
            continue

        visited[current_point] = True
        mst_edges.append(current_point)

        for next_point in range(num_points):
            if not visited[next_point]:
                next_cost = calculate_distance(points[current_point], points[next_point])
                heapq.heappush(min_heap, (next_cost, next_point))

    mst_edges.pop(0)  # Remove the first point as it doesn't represent an edge
    return mst_edges

def construct_preorder_walk(mst_edges, start_vertex):
    """
    Performs a preorder walk on the MST.

    Args:
    mst_edges (list): List of vertices in the MST.
    start_vertex (int): Starting vertex for the walk.

    Returns:
    list: Preorder walk of the MST.
    """
    tree = {vertex: [] for vertex in mst_edges}
    for i in range(1, len(mst_edges)):
        tree[mst_edges[i - 1]].append(mst_edges[i])

    order = []
    def dfs(vertex):
        order.append(vertex)
        for neighbor in tree.get(vertex, []):
            dfs(neighbor)
    dfs(start_vertex)
    return order

def construct_tsp_tour(preorder_walk):
    """
    Constructs the TSP tour by shortcutting the preorder walk.

    Args:
    preorder_walk (list): Preorder walk of the MST.

    Returns:
    list: TSP tour visiting each vertex exactly once.
    """
    visited = set()
    tsp_tour = []
    for vertex in preorder_walk:
        if vertex not in visited:
            visited.add(vertex)
            tsp_tour.append(vertex)
    tsp_tour.append(tsp_tour[0])  # Adding the start vertex at the end to complete the cycle
    return tsp_tour

def calculate_total_distance(tour, points):
    """
    Calculates the total distance of the TSP tour.

    Args:
    tour (list): List of vertices in the order they are visited in the TSP tour.
    points (list of tuples): Coordinates of the points.

    Returns:
    float: Total distance of the TSP tour.
    """
    total_distance = 0
    for i in range(len(tour) - 1):
        total_distance += calculate_distance(points[tour[i]], points[tour[i+1]])
    return total_distance

if __name__ == "__main__":
    # Example usage
    file_path = sys.argv[1]  # Command line argument for TSP file path
    points = read_tsp_file(file_path)
    mst_edges = prim_mst(points)
    preorder_walk = construct_preorder_walk(mst_edges, mst_edges[0])
    tsp_tour = construct_tsp_tour(preorder_walk)
    total_distance = calculate_total_distance(tsp_tour, points)
    print("TSP Tour:", tsp_tour)
    print("Total Distance:", total_distance)

