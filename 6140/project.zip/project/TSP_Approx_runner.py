import sys
import time
from TSP_Approx import read_tsp_file, prim_mst, construct_preorder_walk, construct_tsp_tour, calculate_total_distance

def run_approx_algorithm(file_path, output_file_path):
    """
    Runs the 2-approximation algorithm for TSP and writes the results to a file.

    Args:
    file_path (str): Path to the TSP file.
    output_file_path (str): Path to the output file for storing results.
    """
    start_time = time.time()

    # Running the 2-approximation algorithm
    points = read_tsp_file(file_path)
    mst_edges = prim_mst(points)
    preorder_walk = construct_preorder_walk(mst_edges, mst_edges[0])
    tsp_tour = construct_tsp_tour(preorder_walk)
    total_distance = calculate_total_distance(tsp_tour, points)

    end_time = time.time()
    execution_time = end_time - start_time

    # Writing results to the output file
    with open(output_file_path, 'w') as file:
        file.write(f"Total Distance: {total_distance}\n")
        file.write(f"TSP Tour: {','.join(map(str, tsp_tour))}\n")

    return execution_time

if __name__ == "__main__":
    tsp_file_path = sys.argv[1]  # TSP file path from command line
    output_file_path = sys.argv[2]  # Output file path from command line
    time_file_path = sys.argv[3]  # File path to record execution time

    execution_time = run_approx_algorithm(tsp_file_path, output_file_path)

    # Recording execution time
    with open(time_file_path, 'a') as time_file:
        time_file.write(f"{tsp_file_path}: {execution_time}\n")

