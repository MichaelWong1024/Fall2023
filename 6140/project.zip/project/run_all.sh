#!/bin/bash

# Directory containing TSP data files
DATA_DIR="DATA"

# Algorithm to use
ALGORITHM="Approx"  # Change this to BF or LS as needed

# Cut-off time in seconds
CUTOFF_TIME=300  # Modify this value as per your requirement

# Loop through each .tsp file in the DATA directory
for tsp_file in $DATA_DIR/*.tsp; do
    # Extract the base name of the file for output naming
    base_name=$(basename $tsp_file .tsp)

    # Construct the output file name
    output_file="Approx_sol/${base_name}_${ALGORITHM}_${CUTOFF_TIME}.sol"

    # Run the algorithm
    ./exec -inst $tsp_file -alg $ALGORITHM -time $CUTOFF_TIME -out $output_file

    echo "Processed $tsp_file"
done

echo "All TSP files processed."

